import numpy as np
import util

def main(train_path, valid_path, save_path):
    """Problem: Gaussian discriminant analysis (GDA)

    Args:
        train_path: Path to CSV file containing dataset for training.
        valid_path: Path to CSV file containing dataset for validation.
        save_path: Path to save predicted probabilities using np.savetxt().
    """
    # Load dataset
    x_train, y_train = util.load_dataset(train_path, add_intercept=False)

    # *** START CODE HERE ***
    # Train a GDA classifier
    clf = GDA()
    clf.fit(x_train, y_train)

    x_valid, y_valid = util.load_dataset(valid_path, add_intercept=False)
    y_pred = clf.predict(x_valid)
    # Plot decision boundary on validation set
    plot_path = save_path.replace('.txt', '_plot.png')
    combined_theta = np.insert(clf.theta, 0, clf.theta_0)
    util.plot(x_valid, y_valid, combined_theta, plot_path)
    print(combined_theta)
    # Use np.savetxt to save outputs from validation set to save_path
    np.savetxt(save_path, y_pred)
    # *** END CODE HERE ***
    


class GDA:
    """Gaussian Discriminant Analysis.

    Example usage:
        > clf = GDA()
        > clf.fit(x_train, y_train)
        > clf.predict(x_eval)
    """
    def __init__(self, step_size=1, max_iter=10000, eps=1e-5,
                 theta_0=None, verbose=True):
        """
        Args:
            step_size: Step size for iterative solvers only.
            max_iter: Maximum number of iterations for the solver.
            eps: Threshold for determining convergence.
            theta_0: Initial guess for theta. If None, use the zero vector.
            verbose: Print loss values during training.
        """
        self.theta = theta_0
        self.step_size = step_size
        self.max_iter = max_iter
        self.eps = eps
        self.verbose = verbose
        self.theta_0 = 0

    def fit(self, x, y):
        """Fit a GDA model to training set given by x and y by updating
        self.theta.

        Args:
            x: Training example inputs. Shape (n_examples, dim).
            y: Training example labels. Shape (n_examples,).
        """
        # *** START CODE HERE ***
        # Find phi, mu_0, mu_1, and sigma
        
        n, d = x.shape
        
        self.phi = np.mean(y)
        
        self.mu_0 = np.dot((1 - y), x) / np.sum(1 - y)
        
        self.mu_1 = np.dot(y, x) / np.sum(y)
        
        self.sigma = np.zeros((x.shape[1], x.shape[1]))
        
        diff_0 = x - self.mu_0
        diff_1 = x - self.mu_1
        for i in range(n):
            if y[i] == 0:
                self.sigma += np.outer(diff_0[i], diff_0[i])
            else:
                self.sigma += np.outer(diff_1[i], diff_1[i])
        self.sigma /= n
        # Write theta in terms of the parameters
        sigma_inv = np.linalg.inv(self.sigma)
        self.theta = np.dot(sigma_inv, self.mu_1 - self.mu_0)
        self.theta_0 = -0.5 * np.dot(np.dot(self.mu_1.T, sigma_inv), self.mu_1) + 0.5 * np.dot(np.dot(self.mu_0.T, sigma_inv), self.mu_0) + np.log(self.phi / (1 - self.phi))
        # *** END CODE HERE ***
    
    def predict(self, x):
        """Make a prediction given new inputs x.

        Args:
            x: Inputs of shape (n_examples, dim).

        Returns:
            Outputs of shape (n_examples,).
        """
        # *** START CODE HERE ***
        logits = np.dot(x, self.theta) + self.theta_0
        probs = 1 / (1 + np.exp(-logits))
        return probs>=0.5
        # *** END CODE HERE

if __name__ == '__main__':
    main(train_path='ds1_train.csv',
         valid_path='ds1_valid.csv',
         save_path='gda_pred_1.txt')

    main(train_path='ds2_train.csv',
         valid_path='ds2_valid.csv',
         save_path='gda_pred_2.txt')

